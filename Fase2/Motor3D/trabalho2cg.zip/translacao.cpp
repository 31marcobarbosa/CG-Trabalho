#include "translacao.h"

Translacao::Translacao() {
	x = 0;
	y = 0;
	z = 0;
};

Translacao::Translacao(float a, float b , float c){
	x = a;
	y = b;
	z = c;
};
