#include "escala.h"

Escala :: Escala() {
	x = 0;
	y = 0;
	z = 0;
};

Escala::Escala(float a, float b , float c){
	x = a;
	y = b;
	z = c;
};
